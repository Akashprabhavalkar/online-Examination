import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
 
  
  baseUrl="http://localhost:8081/";

  constructor(private http:HttpClient,private router:Router) { 
   }

  post=(api:string,data:any)=>{
    const headers = {'content-type': 'application/json'}
    return this.http.post(this.baseUrl+api,data,  {'headers':headers});
  }

  get=(api:string,data:any)=>{
    return this.http.get(this.baseUrl+api,data);
  }
 
}

