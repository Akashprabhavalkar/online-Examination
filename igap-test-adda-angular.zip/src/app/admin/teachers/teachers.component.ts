import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { CookieService } from 'src/app/cookie.service';

@Component({
  selector: 'app-teachers',
  templateUrl: './teachers.component.html',
  styleUrls: ['./teachers.component.css']
})
export class TeachersComponent implements OnInit {
teachers:any;
  constructor(private api:ApiService,private cookie:CookieService,private router:Router) { }

  ngOnInit(): void {
    this.list();
  }

  list()
  {
    let apiurl = "teachers/list";
    let data = this.api.post(apiurl, {});
    data.subscribe((mydata: any) => {
      this.teachers= mydata.data;
      console.log(this.teachers);
    });
  }

  delete(id:string)
  {
    if(confirm("Sure to delete?"))
    {
      let apiurl = "teachers/delete";
    let data = this.api.post(apiurl, {data:{id:id}});
    data.subscribe((mydata: any) => {
      this.list();
    });
    }
  }

}
