import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { CookieService } from 'src/app/cookie.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  allquiz: any;
  public loading: any = true;
  public empty: any = true;
  constructor(private api:ApiService, private router:Router,cookie:CookieService) { }

  ngOnInit(): void {
    this.loading = true
    this.empty = true
    
  }

  
}
