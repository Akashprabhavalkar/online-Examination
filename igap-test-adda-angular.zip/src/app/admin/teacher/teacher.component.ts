import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { CookieService } from 'src/app/cookie.service';




@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent implements OnInit {
teacher:any;
id: string | null = "";
constructor(private api: ApiService, private cookie: CookieService, private router: Router, private activatedRoute: ActivatedRoute) {
}

ngOnInit(): void {
  this.id = this.activatedRoute.snapshot.paramMap.get("id");
  if(this.id != "0")
  {
    let apiurl = "teachers/get";
    let data = this.api.post(apiurl, { data: { id: this.id } });
    data.subscribe((mydata: any) => {
      this.teacher = mydata.data;
      this.show();
    });
  }
  this.show();
}

show = ()=>{
  this.teacher = new FormGroup({
    id: new FormControl(this.teacher == null ? "" : this.teacher._id),
    name: new FormControl(this.teacher == null ? "" : this.teacher.name, Validators.compose([Validators.required])),
    email: new FormControl(this.teacher == null ? "" : this.teacher.email, Validators.compose([Validators.required])),
    mobile_no: new FormControl(this.teacher == null ? "" : this.teacher.mobile_no, Validators.compose([Validators.required])),
    password: new FormControl(this.teacher == null ? "" : this.teacher.password, Validators.compose([Validators.required]))
  });
}

submit = (teacher: any) => {
  let apiurl = "teachers/save";
  let data = this.api.post(apiurl, { data: teacher });
  data.subscribe((mydata: any) => {
    
    this.router.navigate(["admin/teachers"]);
  });
}
}
