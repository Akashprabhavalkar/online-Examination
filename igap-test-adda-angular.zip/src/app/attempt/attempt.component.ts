import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { CookieService } from '../cookie.service';

@Component({
  selector: 'app-attempt',
  templateUrl: './attempt.component.html',
  styleUrls: ['./attempt.component.css']
})
export class AttemptComponent implements OnInit {
  test: any;
  student: any;
  question: any = null;
  questionno : number = 0;

  questions: any;
  question_id: string | null = '';
  testid:string | null = "";
  studentid:string | null = "";
  
  duration = 3600;
  timespent = 0;
  timespentstring:string = "";

  constructor(private api:ApiService, private cookie: CookieService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.testid = this.activatedRoute.snapshot.paramMap.get('testid');
    this.studentid = this.activatedRoute.snapshot.paramMap.get('studentid');

    let apiurl = "tests/get";
    let data = this.api.post(apiurl, { data: { id: this.testid } });
    data.subscribe((mydata: any) => {
      this.test = mydata.data;
    });

    apiurl = "students/get";
    data = this.api.post(apiurl, { data: { id: this.studentid } });
    data.subscribe((mydata: any) => {
      this.student = mydata.data;
    });

    apiurl = 'questions/list';
    data = this.api.post(apiurl, { data: { testid: this.testid } });
    data.subscribe((mydata: any) => {
      console.log(mydata);
      this.questions = mydata.data;
      for(let i = 0; i < this.questions.length; i++)
      {
        this.questions[i]["useranswer"] = "";
        this.questions[i]["visited"] = "N";
      }
      if(this.questions.length)
      this.showquestion(0);
    });

    setInterval(()=>{
      this.timespent++;
      if(this.timespent >= this.duration)
      {
        //Exam finished
      }
      let seconds = this.duration - this.timespent;
      let hours = seconds / 3600;
      seconds = seconds % 3600;
      let minutes = seconds / 60;
      seconds = seconds % 60;
      this.timespentstring = Math.floor(hours) + ":" + Math.floor(minutes) + ":" + Math.floor(seconds);
    }, 1000);


  }
  showquestion(index:number):void{
    this.questionno = index + 1;
    this.question_id = this.questions[index]._id;
    this.question = this.questions[index];
    this.questions[index]["visited"] = "Y";
  }
  answerchanged(answer:string)
  {
    this.questions[this.questionno - 1]["useranswer"] = answer;
  }
  getColor(i:number) {
    if(this.questions[i]["visited"] == "Y")
    {      
        if(this.questions[i]["useranswer"] == "")
          return 'red';
        else
          return 'green';
    }
    else{
      return 'gray';
    }
  }

  movenext()
  {
    if(this.questionno < this.questions.length)
      this.showquestion(this.questionno);
  }

  moveprevious()
  {
    if(this.questionno > 1)
      this.showquestion(this.questionno - 2);
  }

}