import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { CookieService } from '../cookie.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  test: any = null;
  id:string | null = "";
  student:any;

  constructor(private api:ApiService, private cookie: CookieService, private router: Router, private activatedRoute: ActivatedRoute) {    
   }

   ngOnInit(): void {
     this.refreshtest();
  }

  show = ()=>{
    this.student = new FormGroup({
      test_id: new FormControl(this.id),
      name: new FormControl("", Validators.compose([Validators.required])),
      email: new FormControl("", Validators.compose([Validators.required])),
      mobile_no: new FormControl("", Validators.compose([Validators.required]))   
    });
  }

  submit = (student: any) => {
    //console.log(student);
    let apiurl = "students/save";
    let data = this.api.post(apiurl, { data: student });
    data.subscribe((mydata: any) => {
      let studentid = mydata._id;
      // console.log(mydata);
      let path = "attempt/" + this.id + "/" + studentid;
      this.router.navigate([path]);

    });
  }

  refreshtest()
  {
    if(this.cookie.get("usertype") != "student")
    {
     this.cookie.set("usertype", "student");
     window.location.reload();
    }
   this.id = this.activatedRoute.snapshot.paramMap.get("id");
   let apiurl = "tests/get";
   let data = this.api.post(apiurl, { data: { id: this.id } });
     data.subscribe((mydata: any) => {
       this.test = mydata.data;

   });
   this.show();
  }
}
