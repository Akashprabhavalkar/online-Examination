import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from '../cookie.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
name:string="";
userloggedin=false;
usertype="";
  constructor(private cookie:CookieService,private router:Router) { }

  ngOnInit(): void {
    this.name=this.cookie.get("name");
    this.usertype = this.cookie.get("usertype");
    console.log("Hello" + this.usertype);
    if(this.cookie.get("usertype") == ""){
      this.userloggedin=false;
    }
    else{
      this.userloggedin=true;      
    }
  }

  logout(){
    this.cookie.delete("userid");
    this.cookie.delete("name");
    this.cookie.delete("usertype");
    this.cookie.delete("authkey");
    window.location.href = "/";
  }
}
