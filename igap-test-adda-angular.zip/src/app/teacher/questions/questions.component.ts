import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { CookieService } from 'src/app/cookie.service';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
questions:any;
testid:any;
id: string | null = "";
  constructor(private api:ApiService,private cookie:CookieService,private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.list();
  }

  list()
  {   this.testid = this.activatedRoute.snapshot.paramMap.get("testid");
  
    let apiurl = "questions/list";
    let data = this.api.post(apiurl, { data: { testid: this.testid } });
    data.subscribe((mydata: any) => {
      this.questions= mydata.data;
      console.log(this.questions);

    });
  }

  delete(id:string)
  {
    if(confirm("Sure to delete?"))
    {
      let apiurl = "questions/delete";
    let data = this.api.post(apiurl, {data:{id:id}});
    data.subscribe((mydata: any) => {
      this.list();
    });
    }
  }
}
