import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { CookieService } from 'src/app/cookie.service';

@Component({
  selector: 'app-tests',
  templateUrl: './tests.component.html',
  styleUrls: ['./tests.component.css']
})
export class TestsComponent implements OnInit {
  teacherid = "";
  tests: any;

  constructor(private api: ApiService, private cookie: CookieService, private router: Router) {
  }

  ngOnInit(): void {
    this.teacherid = this.cookie.get("teacherid");
    this.list();
  }

  list() {
    let apiurl = "tests/list";    
    console.log({ data: { teacherid: this.teacherid } });
    let data = this.api.post(apiurl, { data: { teacherid: this.teacherid } });
    data.subscribe((mydata: any) => {
      this.tests = mydata.data;
      console.log(this.tests);
    });
  }

  delete(id: string) {
    if (confirm("Sure to delete?")) {
      let apiurl = "tests/delete";
      let data = this.api.post(apiurl, { data: { id: id } });
      data.subscribe((mydata: any) => {
        this.list();
      });
    }
  }
}

