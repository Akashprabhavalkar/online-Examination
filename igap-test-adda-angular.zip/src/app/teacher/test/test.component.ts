
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'src/app/cookie.service';
import { ApiService } from 'src/app/api.service';



@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  test: any;
  id:string | null = "";

  constructor(private api:ApiService, private cookie: CookieService, private router: Router, private activatedRoute: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get("id");
    if(this.id != "0")
    {
      let apiurl = "tests/get";
      let data = this.api.post(apiurl, { data: { id: this.id } });
      data.subscribe((mydata: any) => {
        this.test = mydata.data;
        this.show();
      });
    }
    this.show();
  }

  show = ()=>{
    this.test = new FormGroup({
      id: new FormControl(this.test == null ? "" : this.test._id),
      teacher_id: new FormControl(this.cookie.get("teacherid")),
      title: new FormControl(this.test == null ? "" : this.test.title, Validators.compose([Validators.required])),
      instruction: new FormControl(this.test == null ? "" : this.test.instruction, Validators.compose([Validators.required])),
      right_answer: new FormControl(this.test == null ? "" : this.test.right_answer, Validators.compose([Validators.required])),
      wrong_answer: new FormControl(this.test == null ? "" : this.test.wrong_answer, Validators.compose([Validators.required]))
    });
  }

  submit = (test: any) => {
    let apiurl = "tests/save";
    let data = this.api.post(apiurl, { data: test });
    data.subscribe((mydata: any) => {
      this.router.navigate(["teacher/tests"]);
    });
  }
}
