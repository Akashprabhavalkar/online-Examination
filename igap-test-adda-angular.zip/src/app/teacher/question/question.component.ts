import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { CookieService } from 'src/app/cookie.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {
question:any;
testid:any;
id: string | null = "";
test:any;

  constructor(private api:ApiService, private cookie:CookieService, private router:Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {

    this.testid = this.activatedRoute.snapshot.paramMap.get("testid");
    let apiurl = "tests/get";
    let data = this.api.post(apiurl, { data: { id: this.testid } });
    data.subscribe((mydata: any) => {
      this.test = mydata.data;
    });

    this.id = this.activatedRoute.snapshot.paramMap.get("id");
    if(this.id != "0")
    {
      let apiurl = "questions/get";
      let data = this.api.post(apiurl, { data: { id: this.id } });
      data.subscribe((mydata: any) => {
        this.question = mydata.data;
        this.show();
      });
    }
    this.show(); 
  }
  
  show = ()=>{
    this.question = new FormGroup({
      id: new FormControl(this.question == null ? "" : this.question._id),
      test_id: new FormControl(this.testid),
      question_id: new FormControl(this.question == null ? "" : this.question.question_id),

      question_name: new FormControl(this.question == null ? "" : this.question.question_name),

      option_1: new FormControl(this.question == null ? "" : this.question.option_1, Validators.compose([Validators.required])),

      option_2: new FormControl(this.question == null ? "" : this.question.option_2, Validators.compose([Validators.required])),

      option_3: new FormControl(this.question == null ? "" : this.question.option_3, Validators.compose([Validators.required])),

      option_4: new FormControl(this.question == null ? "" : this.question.option_4, Validators.compose([Validators.required])),

      answer: new FormControl(this.question == null ? "" : this.question.answer, Validators.compose([Validators.required])),

      
  
    });
  }
  
  submit = (question: any) => {
    let apiurl = "questions/save";
    let data = this.api.post(apiurl, { data:question });
    data.subscribe((mydata: any) => {
      
      this.router.navigate(["teacher/questions/" + this.testid ]);
      console.log(mydata);
    });
  }
}
