import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './admin/login/login.component';
import { LoginComponent as TeacherLoginComponent } from './teacher/login/login.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { TeachersComponent } from './admin/teachers/teachers.component';
import { TeacherComponent } from './admin/teacher/teacher.component';
import { TestsComponent } from './teacher/tests/tests.component';
import { TestComponent } from './teacher/test/test.component';
import { ApiService } from './api.service';
import { CookieService } from './cookie.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { QuestionsComponent } from './teacher/questions/questions.component';
import { QuestionComponent } from './teacher/question/question.component';
import { TestComponent as StudentTestComponent } from './test/test.component';
import { AttemptComponent } from './attempt/attempt.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
    DashboardComponent,
    TeachersComponent,
    TeacherComponent,
    TestsComponent,
    TeacherLoginComponent,
    TestComponent,
    QuestionsComponent,
    QuestionComponent,
    StudentTestComponent,
    AttemptComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule   
    
  ],
  providers: [ApiService,CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
