import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent as AdminLoginComponent } from './admin/login/login.component';
import { LoginComponent as TeacherLoginComponent } from './teacher/login/login.component';

import { HomeComponent } from './home/home.component';
import { DashboardComponent as AdminDashboardComponent } from './admin/dashboard/dashboard.component';
import { DashboardComponent as TeacherDashboardComponent } from './teacher/dashboard/dashboard.component';
import { TeachersComponent } from './admin/teachers/teachers.component';
import { TeacherComponent } from './admin/teacher/teacher.component';
import { TestsComponent } from './teacher/tests/tests.component';
import { TestComponent } from './teacher/test/test.component';
import { QuestionsComponent } from './teacher/questions/questions.component';
import { QuestionComponent } from './teacher/question/question.component';
import { TestComponent as StudentTestComponent } from './test/test.component';
import { AttemptComponent } from './attempt/attempt.component';


const routes: Routes = [
  {path:"", component:HomeComponent},
  {path:"admin/login", component:AdminLoginComponent},
  {path:"admin/dashboard", component:AdminDashboardComponent},
  {path:"admin/teachers", component:TeachersComponent},
  {path:"admin/teacher/:id", component:TeacherComponent},

  {path:"teacher/login", component:TeacherLoginComponent},
  {path:"teacher/dashboard", component:TeacherDashboardComponent},
  {path:"teacher/tests", component:TestsComponent},
  {path:"teacher/test/:id", component:TestComponent},
  {path:"teacher/questions/:testid", component:QuestionsComponent},
  {path:"teacher/question/:testid/:id", component:QuestionComponent},

  {path:"test/:id", component:StudentTestComponent},
  {path:"attempt/:testid/:studentid", component:AttemptComponent},
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
