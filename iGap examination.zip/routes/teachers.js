var express = require("express");
var bodyparser = require("body-parser");


const Teachers = require("../models/Teachers");
var jsonparser = bodyparser.json();
const router = express.Router();

router.post("/teacherlogin", async(req, res) => {
    let body = req.body;
    let teacher = await Teachers.find().and([{ email: body.data.email }, { password: body.data.password }]);
    let data = {
        "data": {
            "status": "failed"
        }
    }
    if (teacher.length != 0) {
        let authkey = (Math.random() + 1).toString(36).substring(2);

        teacher = await Teachers.findById(teacher[0]._id);
        teacher.authkey = authkey;
        teacher.save();
        data = {
            "data": {
                "_id": teacher._id,
                "status": "success",
                "name": teacher.name,
                "email": teacher.email,
                "mobile_no": teacher.mobile_no,
                "authkey": authkey
            }
        }
    }
    res.end(JSON.stringify(data));
});

router.post("/save", async(req, res) => {
    let body = req.body;
    let teachers = new Teachers();
    if (body.data.id != "") {
        teachers = await Teachers.findById(body.data.id);
    }
    teachers.name = body.data.name;
    teachers.mobile_no = body.data.mobile_no;
    teachers.email = body.data.email;
    teachers.password = body.data.password;
    teachers.authkey = "sdsadsa";
    teachers.save().then(result => {
        res.end(JSON.stringify(result));
    }, err => {
        res.end(JSON.stringify(err));
    });
});

router.post("/list", async(req, res) => {
    let teachers = await Teachers.find();
    res.json({ data: teachers });
});

router.post("/get", async(req, res) => {
    let body = req.body;

    let teachers = await Teachers.findById(body.data.id);
    res.json({ data: teachers });
});

router.post("/delete", async(req, res) => {
    let body = req.body;

    await Teachers.findByIdAndDelete(body.data.id);
    let data = {
        "data": {
            "status": "success"
        }
    }
    res.end(JSON.stringify(data));
});

module.exports = router;