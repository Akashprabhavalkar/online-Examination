const mongoose = require("mongoose");
//const { MongoDBNamespace } = require("mongoose"/node_modules/mongodb);
const Schema = mongoose.Schema;
const schema = new Schema({
    test_id: {
        type: String
    },

    question_id: {
        type: String
    },
    attendance: {
        type: String
    },
    view_right_answer: {
        type: String
    }
})
const Attendance = mongoose.model("attendance", schema, "attendance");
module.exports = Attendance;