const mongoose = require("mongoose");
//const { MongoDBNamespace } = require("mongoose"/node_modules/mongodb);
const Schema = mongoose.Schema;
const schema = new Schema({
    teacher_id: {
        type: String,
    },
    title: {
        type: String,
    },
    instruction: {
        type: String,

    },
    wrong_answer: {
        type: String,
    },
    right_answer: {
        type: String,
    },
    status: {
        type: String,
    },
    count: {
        type: String,
    }
})
const Tests = mongoose.model("tests", schema);
module.exports = Tests;