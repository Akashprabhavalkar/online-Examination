const mongoose = require("mongoose");
//const { MongoDBNamespace } = require("mongoose"/node_modules/mongodb);
const Schema = mongoose.Schema;
const schema = new Schema({
    test_id: {
        type: String

    },

    question_id: {
        type: String
    },
    question_name: {
        type: String
    },
    option_1: {
        type: String
    },
    option_2: {
        type: String
    },
    option_3: {
        type: String
    },
    option_4: {
        type: String
    },
    answer: {
        type: String,
        required: true
    }
})
const Questions = mongoose.model("questions", schema);
module.exports = Questions;